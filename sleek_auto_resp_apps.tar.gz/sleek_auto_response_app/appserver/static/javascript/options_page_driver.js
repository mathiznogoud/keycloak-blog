require.config({
    paths: {
        optionsPage: "../app/sleek_auto_response_app/javascript/viewsdist/options_page",
        react: "../app/sleek_auto_response_app/javascript/vendor/react.production.min",
        ReactDOM: "../app/sleek_auto_response_app/javascript/vendor/react-dom.production.min",
        bootstrap: "../app/sleek_auto_response_app/javascript/vendor/bootstrap.bundle.min",
        axios: "../app/sleek_auto_response_app/javascript/vendor/axios.min",
    },
    scriptType: "module",
});

require([
    "react", 
    "ReactDOM",
    "optionsPage",
    "bootstrap",
    "axios",
], function(react, ReactDOM, optionsPage, bootstrap, axios) {
    ReactDOM.render(optionsPage, document.getElementById("myRoot"));
});
