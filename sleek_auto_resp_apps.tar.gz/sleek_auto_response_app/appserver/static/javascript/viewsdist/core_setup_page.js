import * as SleekHelpers from "./helpers/sleek_auto_response_helpers.js";
define(["react", "splunkjs/splunk", "bootstrap", "axios"], function(React, splunkJsSdk, bootstrap, axios) {
    const e = React.createElement;
    class SetupPage extends React.Component {
        constructor(props) {
            super(props);
            this.state = {
                keyInput: "",
                loaded: true,
                errored: false,
                errormsg: ""
            };
            this.handleSubmit = this.handleSubmit.bind(this);
            this.handleChange = this.handleChange.bind(this);
        }

        async performSetup() {
            const service = SleekHelpers.createSplunkJsSdkService(splunkJsSdk);
            await SleekHelpers.writeKeyToSecretStore(service, this.state.keyInput);

            await SleekHelpers.setConfigurationFileProperty(service, "app", "install", {
                "is_configured": "true"
            });
            await SleekHelpers.reloadSplunkApp(service);
            alert("Success! Redirecting to options page...");
            window.location.href = "/app/sleek_auto_response_app"
        }
        async handleSubmit(event) {
            event.preventDefault();
            document.getElementById("submitBtn").disabled = true;
            try {
                await this.performSetup()
            } catch (error) {
                if (error instanceof SleekHelpers.SleekAutoResponseException) {
                    alert("There was an error setting up the app: " + error.message)
                } else {
                    alert("There was an error setting up the app: " + error.name + ": " + error.message + ". Detailed info: " + error.stack)
                }
                document.getElementById("submitBtn").disabled = false
            }
        }
        handleChange(event) {
            this.setState({
                keyInput: event.target.value
            })
        }
        renderErrored() {
            return e("div", {
                className: "alert alert-error"
            }, e("h4", {
                className: "alert-heading"
            }, "Error"), e("p", null, this.state.errormsg), e("button", {
                className: "btn btn-primary",
                onClick: () => {
                    window.location.href = "/app/sleek_auto_response_app/Core_Setup"
                }
            }, "Try again"))
        }
        renderLoading() {
            return e("div", {
                className: "loading-container"
            }, e("div", {
                className: "loading-indicator"
            }, e("p", null, "Loading...")))
        }
        render() {
            if (this.state.errored) {
                return this.renderErrored()
            }
            if (!this.state.loaded) {
                return this.renderLoading()
            }
            return e("div", {
                className: "container-fluid"
            }, e("h1", {
                className: "display-6"
            }, "Sleek Auto Response App Setup"), e("p", {
                className: "lead"
            }, "To setup the Sleek Auto Response App, please enter your API key in the field below."), e("form", {
                className: "mb-3 align-self-stretch",
                onSubmit: this.handleSubmit,
                id: "setupForm"
            }, e("div", {
                className: "mb-3"
            }, e("label", {
                htmlFor: "apiKeyInput",
                className: "form-label"
            }, "API Key"), e("input", {
                type: "password",
                className: "form-control",
                id: "apiKeyInput",
                value: this.state.keyInput,
                onChange: this.handleChange
            })), e("button", {
                type: "submit",
                className: "btn btn-primary",
                id: "submitBtn"
            }, "Save")))
        }
    }
    return e(SetupPage)
});