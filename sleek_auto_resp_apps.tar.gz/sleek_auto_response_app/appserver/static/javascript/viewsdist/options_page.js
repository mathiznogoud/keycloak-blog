import * as SleekHelpers from "./helpers/sleek_auto_response_helpers.js";
define(["react", "splunkjs/splunk", "bootstrap"], function(React, splunkJsSdk, bootstrap) {
    const e = React.createElement;

    class OptionsPage extends React.Component {
        constructor(props) {
            super(props);
            this.state = {
                apiKey: "",
                loaded: false,
                errored: false,
                errormsg: ""
            };
            this.handleDelete = this.handleDelete.bind(this);
        }

        async componentDidMount() {
            try {
                const service = SleekHelpers.createSplunkJsSdkService(splunkJsSdk);
                const key = await SleekHelpers.getKeyFromSecretStore(service);
                this.setState({
                    apiKey: key ? "API Key is set." : "API Key is not set.",
                    loaded: true
                });
            } catch (err) {
                this.setState({
                    errored: true,
                    errormsg: "Error fetching API key: " + err.message,
                    loaded: true
                });
            }
        }

        async handleDelete() {
            if (!confirm("Are you sure you want to delete the API key? This will require you to re-run the setup.")) {
                return;
            }

            try {
                const service = SleekHelpers.createSplunkJsSdkService(splunkJsSdk);
                await SleekHelpers.deleteApiKey(service);
                await SleekHelpers.setConfigurationFileProperty(service, "app", "install", {
                    "is_configured": "false"
                });
                await SleekHelpers.reloadSplunkApp(service);
                alert("API Key deleted successfully. The application will now reload.");
                window.location.reload();
            } catch (err) {
                alert("Failed to delete API key: " + err.message);
            }
        }

        render() {
            if (!this.state.loaded) {
                return e("p", null, "Loading...");
            }

            if (this.state.errored) {
                return e("div", { className: "alert alert-danger" }, this.state.errormsg);
            }

            return e("div", { className: "container-fluid" },
                e("h1", { className: "display-6" }, "API Key Management"),
                e("p", null, this.state.apiKey),
                e("button", {
                    className: "btn btn-danger",
                    onClick: this.handleDelete,
                    disabled: this.state.apiKey === "API Key is not set."
                }, "Delete API Key")
            );
        }
    }

    return e(OptionsPage);
});