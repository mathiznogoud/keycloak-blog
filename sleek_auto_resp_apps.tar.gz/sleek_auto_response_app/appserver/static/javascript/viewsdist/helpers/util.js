function promisify(fn) {
    return (...args) => {
        return new Promise((resolve, reject) => {
            function callback(err, result) {
                if (err) {
                    reject(err)
                } else {
                    resolve(result)
                }
            }
            args.push(callback);
            fn.call(this, ...args)
        })
    }
}
export {
    promisify
};