import {
    promisify
} from "./util.js";
async function update_configuration_file(splunk_js_sdk_service, configuration_file_name, stanza_name, properties) {
    var splunk_js_sdk_service_configurations = splunk_js_sdk_service.configurations({});
    await splunk_js_sdk_service_configurations.fetch();
    var configuration_file_exist = does_configuration_file_exist(splunk_js_sdk_service_configurations, configuration_file_name);
    if (!configuration_file_exist) {
        await create_configuration_file(splunk_js_sdk_service_configurations, configuration_file_name);
        await splunk_js_sdk_service_configurations.fetch()
    }
    var configuration_file_accessor = get_configuration_file(splunk_js_sdk_service_configurations, configuration_file_name);
    await configuration_file_accessor.fetch();
    var stanza_exist = does_stanza_exist(configuration_file_accessor, stanza_name);
    if (!stanza_exist) {
        await create_stanza(configuration_file_accessor, stanza_name)
    }
    await configuration_file_accessor.fetch();
    var configuration_stanza_accessor = get_configuration_file_stanza(configuration_file_accessor, stanza_name);
    await configuration_stanza_accessor.fetch();
    await update_stanza_properties(configuration_stanza_accessor, properties)
};
async function get_stanza_properties(splunk_js_sdk_service, configuration_file_name, stanza_name) {
    var splunk_js_sdk_service_configurations = splunk_js_sdk_service.configurations({});
    await splunk_js_sdk_service_configurations.fetch();
    var configuration_file_exist = does_configuration_file_exist(splunk_js_sdk_service_configurations, configuration_file_name);
    if (!configuration_file_exist) {
        return false
    }
    var configuration_file_accessor = get_configuration_file(splunk_js_sdk_service_configurations, configuration_file_name);
    configuration_file_accessor = await promisify(configuration_file_accessor.fetch)();
    var stanza_exist = does_stanza_exist(configuration_file_accessor, stanza_name);
    if (!stanza_exist) {
        await create_stanza(configuration_file_accessor, stanza_name)
    }
    configuration_file_accessor = await promisify(configuration_file_accessor.fetch)();
    var configuration_stanza_accessor = get_configuration_file_stanza(configuration_file_accessor, stanza_name);
    return configuration_stanza_accessor.properties()
};

function create_configuration_file(configurations_accessor, configuration_file_name) {
    var _parent_context = this;
    return configurations_accessor.create(configuration_file_name, function(_error_response, _created_file) {})
};

function does_configuration_file_exist(configurations_accessor, configuration_file_name) {
    var was_configuration_file_found = false;
    var configuration_files_found = configurations_accessor.list();
    for (var index = 0; index < configuration_files_found.length; index++) {
        var configuration_file_name_found = configuration_files_found[index].name;
        if (configuration_file_name_found === configuration_file_name) {
            was_configuration_file_found = true;
            break
        }
    }
    return was_configuration_file_found
};

function does_stanza_exist(configuration_file_accessor, stanza_name) {
    var was_stanza_found = false;
    var stanzas_found = configuration_file_accessor.list();
    for (var index = 0; index < stanzas_found.length; index++) {
        var stanza_found = stanzas_found[index].name;
        if (stanza_found === stanza_name) {
            was_stanza_found = true;
            break
        }
    }
    return was_stanza_found
};

function does_stanza_property_exist(configuration_stanza_accessor, property_name) {
    var was_property_found = false;
    for (const [key, value] of Object.entries(configuration_stanza_accessor.properties())) {
        if (key === property_name) {
            was_property_found = true;
            break
        }
    }
    return was_property_found
};

function get_configuration_file(configurations_accessor, configuration_file_name) {
    var configuration_file_accessor = configurations_accessor.item(configuration_file_name, {});
    return configuration_file_accessor
};

function get_configuration_file_stanza(configuration_file_accessor, configuration_stanza_name) {
    var configuration_stanza_accessor = configuration_file_accessor.item(configuration_stanza_name, {});
    return configuration_stanza_accessor
};

function get_configuration_file_stanza_property(configuration_file_accessor, configuration_file_name) {
    return null
};

function create_stanza(configuration_file_accessor, new_stanza_name) {
    var parent_context = this;
    return configuration_file_accessor.create(new_stanza_name, function(error_response, created_stanza) {})
};

function update_stanza_properties(configuration_stanza_accessor, new_stanza_properties) {
    var parent_context = this;
    return configuration_stanza_accessor.update(new_stanza_properties, function(error_response, entity) {})
};
export {
    update_configuration_file,
    get_stanza_properties
};