import {
    promisify
} from "./util.js";
import * as SplunkHelpers from "./splunk_helpers.js";
async function reloadSplunkApp(service) {
    var serviceApps = service.apps();
    await promisify(serviceApps.fetch)();
    var currentApp = serviceApps.item("sleek_auto_response_app");
    await promisify(currentApp.reload)()
};
async function batchUpdateKvStore(service, parameters) {
    var stringParams = JSON.stringify(Object.entries(parameters).map(([key, value]) => {
        return {
            "_key": key,
            "value": value
        }
    }));
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll/batch_save", "POST", null, null, stringParams, {
            "Content-Type": "application/json"
        }, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                resolve(coll)
            }
        })
    })
};

function createSplunkJsSdkService(splunkJsSdk) {
    var http = new splunkJsSdk.SplunkWebHttp;
    var application_name_space = {
        owner: "nobody",
        app: "sleek_auto_response_app",
        sharing: "app"
    };
    var service = new splunkJsSdk.Service(http, application_name_space);
    return service
};

async function setKeyValue(service, key, value) {
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll/" + key, "POST", null, null, "{ \"_key\": \"" + key + "\", \"value\":\"" + value + "\" }", {
            "Content-Type": "application/json"
        }, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                resolve(coll)
            }
        })
    })
};
async function getAllKVPairsAsJsonObject(service) {
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll", "GET", null, null, null, null, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                var toReturn = {};
                coll.data.forEach(item => {
                    toReturn[item._key] = item.value
                });
                resolve(toReturn)
            }
        })
    })
};
async function getValueFromKey(service, key) {
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll/" + key, "GET", null, null, null, null, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                resolve(coll.data.value)
            }
        })
    })
};
async function setConfigurationFileProperty(service, configurationFileName, stanzaName, propertiesToUpdate) {
    await SplunkHelpers.update_configuration_file(service, configurationFileName, stanzaName, propertiesToUpdate)
};
async function isKvStoreEmpty(service) {
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll", "GET", null, null, null, null, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                resolve(coll.data.length == 0)
            }
        })
    })
};
async function deleteApiKey(service) {
    var storagePasswords = service.storagePasswords();
    await promisify(storagePasswords.fetch)();
    let sleekApiKey = storagePasswords.item("sleek_auto_response_api_key:admin:");
    if (sleekApiKey) {
        await promisify(sleekApiKey.remove)()
    }
}

async function writeKeyToSecretStore(service, keyInput) {
    var storagePasswords = service.storagePasswords();
    await promisify(storagePasswords.fetch)();
    let sleekApiKey = storagePasswords.item("sleek_auto_response_api_key:admin:");
    if (sleekApiKey) {
        await promisify(sleekApiKey.remove)()
    }
    return new Promise((resolve, reject) => {
        storagePasswords.create({
            name: "admin",
            password: keyInput,
            realm: "sleek_auto_response_api_key"
        }, function(err, storagePassword) {
            if (err) {
                reject(err)
            } else {
                resolve(storagePassword)
            }
        })
    })
};
async function getKeyFromSecretStore(service) {
    try {
        var storagePasswords = service.storagePasswords();
        await promisify(storagePasswords.fetch)();
        let sleekApiKey = storagePasswords.item("sleek_auto_response_api_key:admin:");
        if (sleekApiKey) {
            return sleekApiKey.properties()["clear_password"]
        } else {
            return null
        }
    } catch (err) {
        throw new SleekAutoResponseException("Error retrieving API key from secret store. Do you have the list_all_passwords permission?")
    }
};
async function deleteKvStore(service) {
    return new Promise((resolve, reject) => {
        service.request("storage/collections/data/sleek_auto_response_control_coll", "DELETE", null, null, null, null, function(err, coll) {
            if (err) {
                reject(err)
            } else {
                resolve(coll)
            }
        })
    })
};
class SleekAutoResponseException extends Error {
    constructor(message) {
        super(message);
        this.name = "SleekAutoResponseException"
    }
}
export {
    reloadSplunkApp,
    batchUpdateKvStore,
    createSplunkJsSdkService,
    setKeyValue,
    getAllKVPairsAsJsonObject,
    getValueFromKey,
    setConfigurationFileProperty,
    isKvStoreEmpty,
    deleteApiKey,
    writeKeyToSecretStore,
    getKeyFromSecretStore,
    deleteKvStore,
    SleekAutoResponseException,
};