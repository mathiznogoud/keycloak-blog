require.config({
    paths: {
        coreSetupPage: "../app/sleek_auto_response_app/javascript/viewsdist/core_setup_page",
        react: "../app/sleek_auto_response_app/javascript/vendor/react.production.min",
        ReactDOM: "../app/sleek_auto_response_app/javascript/vendor/react-dom.production.min",
        bootstrap: "../app/sleek_auto_response_app/javascript/vendor/bootstrap.bundle.min",
        axios: "../app/sleek_auto_response_app/javascript/vendor/axios.min",
    },
    scriptType: "module",
});

require([
    "react", 
    "ReactDOM",
    "coreSetupPage",
    "bootstrap",
    "axios",
], function(react, ReactDOM, coreSetupPage, bootstrap, axios) {
    ReactDOM.render(coreSetupPage, document.getElementById("myRoot"));
});
