# Sleek Auto Response App

This is a Splunk app for managing API keys.

## Setup

Install the app and launch it. You'll be directed to a setup page where you must enter your API key to continue.

## Usage

### `getcfitems`

This custom search command retrieves all items from a specified Cloudflare list.

**Syntax:**

```
| getcfitems account_id=<your_cloudflare_account_id> list_id=<your_cloudflare_list_id>
```

**Example:**

```
| getcfitems account_id="ffb0b2200c314816e214ae456dc13d80" list_id="dbaa507444b14475a8adb1745e96ae35"
```

This will return all items from the specified list as Splunk events.
# Binary File Declaration
/opt/splunk/var/data/tabuilder/package/sleek_auto_response_app/bin/sleek_auto_response_app/aob_py3/yaml/_yaml.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
/opt/splunk/var/data/tabuilder/package/sleek_auto_response_app/bin/sleek_auto_response_app/aob_py3/markupsafe/_speedups.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
